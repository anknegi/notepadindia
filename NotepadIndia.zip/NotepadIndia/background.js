chrome.runtime.onInstalled.addListener(()=>{
    alert("Thank you for installing this extension");
});

chrome.bookmarks.onCreated.addListener(()=>{
    console.log('boookmark created');
});
