module.exports = () => {
  return {
    files: [
      'index.html',
      'app.js',
      'style.css'
    ],
    tests: [
      ''
    ],
    env: {
      kind: 'chrome'
    },
    debug: true
  };
};
